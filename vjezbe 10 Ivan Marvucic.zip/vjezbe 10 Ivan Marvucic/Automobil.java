public class Automobil extends Vozilo {

    private double potrosnja; 

    public Automobil(String id, double maxBrzina, double potrosnja) {
        super(id, maxBrzina);
        this.potrosnja = potrosnja;
    }

    @Override
    public double izracunajVrijemeDostave(double udaljenostKm) {
        return udaljenostKm / maxBrzina;
    }

    public double getPotrosnja() {
        return potrosnja;
    }
}

