import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        ArrayList<Vozilo> vozila = new ArrayList<>();
        double udaljenost = 10;

        
        vozila.add(new Bicikl("B1", 20));
        vozila.add(new Motor("M1", 60, 0.05));
        vozila.add(new Automobil("A1", 80, 0.1));

        System.out.println(" Izračunavanje vremena dostave za " + udaljenost + " km \n");

        for (Vozilo v : vozila) {
            v.info();

            double vrijeme = v.izracunajVrijemeDostave(udaljenost);
            System.out.printf("Vrijeme dostave: %.2f h\n", vrijeme);

            if (v instanceof Ekonomican) {
                Ekonomican e = (Ekonomican) v;
                double ukupnaPotrosnja = e.potrosnjaPoKm() * udaljenost;
                System.out.printf("Ukupna potrošnja: %.3f jedinica\n", ukupnaPotrosnja);
            }

            System.out.println();
        }

        System.out.println(" REZIME ");

        for (Vozilo v : vozila) {
            double vrijeme = v.izracunajVrijemeDostave(udaljenost);

            System.out.print(v.id + " -> " + String.format("%.2f", vrijeme) + " h");

            if (v instanceof Ekonomican) {
                Ekonomican e = (Ekonomican) v;
                double ukupnaPotrosnja = e.potrosnjaPoKm() * udaljenost;
                System.out.print(", potrošnja: "+ String.format("%.2f", ukupnaPotrosnja));
            }

            System.out.println();
        }
    }
}
